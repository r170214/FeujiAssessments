package com.exception2.nov20;

public class InsufficientBalance extends Exception 
{
	public InsufficientBalance()
	{
		super();
	}
	public InsufficientBalance(String s)
	{
		super(s);
	}

}

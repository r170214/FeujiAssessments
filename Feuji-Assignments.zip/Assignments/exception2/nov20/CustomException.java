package com.exception2.nov20;

public class CustomException extends Exception 
{
	public CustomException()
	{
		super();
	}
	public CustomException(String s)
	{
		super(s);
	}
}

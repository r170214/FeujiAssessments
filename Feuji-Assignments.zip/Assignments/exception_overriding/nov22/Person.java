package com.exception_overriding.nov22;

public class Person 
{
	
	public Person() {
		super();
	}
	String g;
	int age;
	String name;
	static int num;
	void room() {
		
	}
	 void display()
	{
		this.age=10;
		this.name="raj";
		this.num=20;
	}
//	static void show()
//	{
//		System.out.println("age: "+this.age+" name: "+this.name);
//	}
}

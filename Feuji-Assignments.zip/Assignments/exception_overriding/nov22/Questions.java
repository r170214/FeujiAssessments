package com.exception_overriding.nov22;

public class Questions 
{

/*
 * Hi Team, Do the following questions for practice on Exception Handling with Method Overriding
Case 1: If SuperClass doesn’t declare any exception and subclass declare checked exception
Case 2: If SuperClass doesn’t declare any exception and SubClass declare Unchecked exception
Case 3: If SuperClass declares an exception and SubClass declares exceptions other than the child
 		exception of the SuperClass declared Exception.
Case 4: If SuperClass declares an exception and SubClass declares a child exception of the SuperClass
 	declared Exception.
Case 5: If SuperClass declares an exception and SubClass declares without exception.	
 */
	
}

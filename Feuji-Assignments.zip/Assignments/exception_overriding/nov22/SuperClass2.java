//Case 2: If SuperClass doesn’t declare any exception and SubClass declare Unchecked exception -  no error
package com.exception_overriding.nov22;


public class SuperClass2 
{
	void test() 
	{
		System.out.println("super class");
	}
}

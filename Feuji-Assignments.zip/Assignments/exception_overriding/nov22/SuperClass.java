//case -1: If SuperClass doesn’t declare any exception and subclass declare checked exception - compiletime error
package com.exception_overriding.nov22;

public class SuperClass
{
	void test(){
		System.out.println("super class");
	}
}

package com.exception_overriding.nov22;

import java.io.IOException;

public class SuperClass3 {

	void show()  throws IOException
	{
		System.out.println("super class");
	}
}

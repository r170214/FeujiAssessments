package com.exception_overriding.nov22;

public class SuperClass4 {

	void show() throws RuntimeException
	{
		System.out.println("super class");
	}
}

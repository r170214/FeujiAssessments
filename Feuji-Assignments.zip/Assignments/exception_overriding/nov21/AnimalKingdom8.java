package com.exception_overriding.nov21;

public class AnimalKingdom8 
{
	void eat()
	{
		System.out.println("eating");
	}
	
}

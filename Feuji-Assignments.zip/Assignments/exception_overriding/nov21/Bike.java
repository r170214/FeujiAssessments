package com.exception_overriding.nov21;

public class Bike extends TwoWheeler 
{
	int a=10;
	void display() 
	{
		System.out.println("Vehicle -- twowheeler --  bike");
	}
}

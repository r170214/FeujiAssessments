package com.exception_overriding.nov21;

public class IsARelationShip5 extends SuperClass5{

	public static void main(String[] args) 
	{
		IsARelationShip5 obj = new IsARelationShip5();
		obj.display();
	}

}

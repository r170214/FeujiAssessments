package com.exception_overriding.nov21;

public class SuperClass5 
{
	int a=10;
	int b=20;
	void display()
	{
		System.out.println("a: "+a+"b: "+b);
	}
}

package com.exception_overriding.nov21;

public class Bird extends AnimalKingdom8
{
	void fly()
	{
		System.out.println("flying..");
	}
}

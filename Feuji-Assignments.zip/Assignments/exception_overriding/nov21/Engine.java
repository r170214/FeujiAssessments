package com.exception_overriding.nov21;

public class Engine 
{
	String type = "mahindra";
	double capacity =100;
}

package com.exception_overriding.nov21;

public class Animal1 
{
	String color;
	int age;
	
	void display(String color, int age)
	{
		System.out.println("Animal class");
	}
}

package com.exception_overriding.nov21;

public class Encapsulation {

	public static void main(String[] args) 
	{
		Person2 person = new Person2("shyam",23,'M');
		System.out.println(person.getName());
		System.out.println(person.getAge());
		System.out.println(person.getGender());
		
	}

}

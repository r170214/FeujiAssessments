package com.exception_overriding.nov21;

public class HasARelationship5 {

	public static void main(String[] args)
	{
		Benz benz = new Benz();
		benz.display();
	}

}

package com.exception_overriding.nov21;

public class SuperClass 
{
	void display(int var1)
	{
		System.out.println("SuperClass , var1: "+var1);
	}
}

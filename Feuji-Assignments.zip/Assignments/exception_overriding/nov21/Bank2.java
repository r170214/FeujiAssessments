package com.exception_overriding.nov21;

public abstract class Bank2
{
	abstract void deposit();
	abstract void withdraw();
	
}
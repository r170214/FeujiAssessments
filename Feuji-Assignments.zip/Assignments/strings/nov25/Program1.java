package com.strings.nov25;

public class Program1 
{
	public static void main(String[] args) 
	{
		String str=null;
		if(str.equalsIgnoreCase(null))
		{
			System.out.println("string is null");
		}
		else
		{
			System.out.println("not null");
		}
	}
}

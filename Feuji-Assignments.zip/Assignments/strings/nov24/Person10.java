package com.strings.nov24;

public class Person10 // extends String
{

}

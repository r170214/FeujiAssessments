package com.strings.nov24;

public class PrimitiveToString12 {

	public static void main(String[] args) 
	{
		int i=10;
		String str=""+i;
		
		byte b =10;
		String str2=""+b;
		
		short s=20;
		String str3=""+b;
		
		long l=20;
		String str4=""+l;
		
		float f =35.6f;
		String str5 =""+f;
		
		double d=90.0;
		String str6=""+d;
		
		boolean bb =true;
		String str7=""+bb;
		
		char ch='a';
		String str8=""+ch;
		
		System.out.println(str);
		System.out.println(str2);
		System.out.println(str3);
		System.out.println(str4);
		System.out.println(str5);
		System.out.println(str6);
		System.out.println(str7);
		System.out.println(str8);
	}

}

package com.accessmodifiers.nov15;

public class Question8b
{
	
	public void change()
	{
		Question8 object = new Question8();
		//object.name="raj"; we can not modify final member variables outside of class
		
	}
	public static void main(String[] args) {
		
	}
}

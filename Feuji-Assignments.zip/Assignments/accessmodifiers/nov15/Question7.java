/*
 * 7. Declare a final class and extend that within the package classes and in another
package classes
 */
package com.accessmodifiers.nov15;

public final class Question7 
{
	static int age=10;
	String name="gill";
	
	public void display()
	{
		System.out.println("it is concreate method..");
	}
}

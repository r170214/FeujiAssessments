// Declare a class with combination of multiple non-access modifiers
package com.accessmodifiers.nov15;

public abstract class Question10 
{
	//we can not use multiple non access modifiers for a single class
}

package com.accessmodifiers.nov15;

public class Questions {


/*
 1. Write a program to access class properties through object and inheritance
2. Write a program that includes all the access modifiers (on variables and methods) in
one package and access them in some other package class.
3. Write a program that includes all the non-access modifiers (on variables and
methods).
4. Write a program to show the difference between default and protected access
modifiers.
5. Declare an abstract class and try to create the object to access the properties.
6. Declare an abstract class and access the properties in right way.
7. Declare a final class and extend that within the package classes and in another
package classes.
8. Declare final variables and try to change the value of that variable within the class
and in another class.
9. Declare final method and try to override that method in subclass.
10. Declare a class with combination of multiple non-access modifiers
 */
}
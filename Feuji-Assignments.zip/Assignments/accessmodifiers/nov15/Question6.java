/*
 * 6. Declare an abstract class and access the properties in right way.

 */

package com.accessmodifiers.nov15;

public abstract class Question6 
{
	static int age=10;
	String name="gill";
	public abstract void display();
	public void concreateMethod()
	{
		System.out.println("it is concreate method..");
	}
}

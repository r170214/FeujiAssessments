//1. Write a program to access class properties through object and inheritance

package com.accessmodifiers.nov15;

public class Question1a 
{
	String name;
	int age;
	long phone;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	
	
}

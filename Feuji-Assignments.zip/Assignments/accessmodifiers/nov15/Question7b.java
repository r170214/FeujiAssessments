package com.accessmodifiers.nov15;

public class Question7b //extends Question7
{
	
}

/*
final classes can't be inherited , they looses the property of becoming a parent class
why because , if it's properties are inherited , then there is chance of overriding (final members 
can't be modified)so,we can't extend final class
*/
package com.accessmodifiers.nov15;

public abstract class Question5 
{
	int age=10;
	String name="siraj";
	
	abstract void display();
	public static void main(String[] args) 
	{
//		Question5 object = new Question5();
		/*
		 * we can't instantiate abstract class
		 */
	}
}

package com.accessmodifiers.nov15b;
import com.accessmodifiers.nov15.Question7;
public class Question7c //extends Question7
{

}
//we can not inherit final class from outside of package also
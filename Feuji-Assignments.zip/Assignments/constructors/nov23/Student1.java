/*
 * 1.Write a program to print the names of students by creating a Student class. s
 * If no name is passed while creating an object of Student class, then the name should be "Unknown",
 *  otherwise the name should be equal to the String value passed while creating object of Student class.

 */
package com.constructors.nov23;

public class Student1
{
	String name="Unknown";
	public Student1()
	{
		this.name=name;
	}
	public Student1(String name)
	{
		this.name=name;
	}
	
}

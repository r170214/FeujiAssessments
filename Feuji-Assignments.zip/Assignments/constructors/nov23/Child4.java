package com.constructors.nov23;

public class Child4 extends Father4 //, Mother
{
	public static void main(String[] args) 
	{
		Child4 child = new Child4();
		child.property();
	}
}

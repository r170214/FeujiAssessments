//4.Write a program which demonstrates the diamond Problem?

package com.constructors.nov23;

public class Father4 
{
	double money;
	public Father4()
	{
		super();
		System.out.println("Father class");
	}
	
	void property()
	{
		System.out.println("father property");
	}
}

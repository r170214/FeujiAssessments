package com.constructors.nov23;

public class Mother4 
{
	double cash;
	public Mother4()
	{
		System.out.println("Mother Class");
	}
	public void display()
	{
		System.out.println("mother property");
	}
}

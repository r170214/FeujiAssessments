package com.interfaceandabstract.nov16;

public abstract class Vehicle6 
{
	private int a=10;
	protected int b=20;
	public abstract void drive();
	 abstract void details();
}

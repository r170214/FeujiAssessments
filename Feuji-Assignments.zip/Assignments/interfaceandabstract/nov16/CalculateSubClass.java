package com.interfaceandabstract.nov16;

public class CalculateSubClass implements Calculate1
{

	public void calculate()
	{
		System.out.println("calculate method implementing in CalculateSubClass");
	}
}

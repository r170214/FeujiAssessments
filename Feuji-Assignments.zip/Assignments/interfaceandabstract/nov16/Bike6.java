package com.interfaceandabstract.nov16;
//extends Vehicle6
public interface Bike6
{
	

/*
 * The type Vehicle6 cannot be a superinterface of Bike6; a superinterface must be an interface
 */
}
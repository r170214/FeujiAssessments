package com.interfaceandabstract.nov16;

public abstract class Car2 
{
	 static String brandName;
	 int carNo;
	 abstract void driving();
	 void details()
	{
		System.out.println("car details are printed here...");
	}
//	private void simple()
//	{
//		details();
//	}
}

package com.interfaceandabstract.nov16;

public interface Mango extends Fruit4
{
	String name ="Mango";
	String color="Yellow";
	void details();
}

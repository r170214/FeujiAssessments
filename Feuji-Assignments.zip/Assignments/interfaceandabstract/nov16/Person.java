package com.interfaceandabstract.nov16;

public interface Person 
{
	public void sleep();
//	protected void run();
//	private void eat();
	
	/*
	 * we can not create methods with other access modifiers except public, 
	 * why because in interface all the methods are by default public
	 */
	 void read();
}

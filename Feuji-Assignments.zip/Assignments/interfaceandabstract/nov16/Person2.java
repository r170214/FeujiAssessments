package com.interfaceandabstract.nov16;

public interface Person2
{
	String name="person";
	int age=23;
	
	void details();	
}

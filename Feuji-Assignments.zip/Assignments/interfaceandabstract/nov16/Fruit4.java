package com.interfaceandabstract.nov16;

public interface Fruit4 
{
	String name="fruit";
	String color= "yellow";
	void details();
}

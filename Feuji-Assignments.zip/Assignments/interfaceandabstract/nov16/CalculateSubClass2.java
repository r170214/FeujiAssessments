package com.interfaceandabstract.nov16;

public class CalculateSubClass2 implements Calculate1
{
	public void calculate()
	{
		System.out.println("calculate method implementing in CalculateSubClass2");
	}
}

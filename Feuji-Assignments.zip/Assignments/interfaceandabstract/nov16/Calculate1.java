package com.interfaceandabstract.nov16;

public interface Calculate1 
{
	void calculate();
	
}

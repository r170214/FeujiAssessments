package com.operators.nov9;

public class RelationalOperators 
{
	boolean greaterThan(int value1 , int value2)
	{
		return value1>value2;
	}
	boolean lessThan(int value1 , int value2)
	{
		return value1<value2;
	}
	boolean greaterThanOrEqual(int value1 , int value2)
	{
		return value1>=value2;
	}
	boolean lessThanOrEqual(int value1 , int value2)
	{
		return value1<=value2;
	}
	boolean equal(int value1 , int value2)
	{
		return value1==value2;
	}
}

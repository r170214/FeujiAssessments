//2. How many ways we can declare arrays, represent in a program 

package com.arrays.nov8;

public class DifferentWaysOfArrayRepresentation2 {

	public static void main(String[] args) 
	{
		//there are 2 different ways to represent an array
		int[] array =new int[5];
		System.out.println(array[0]);
		int[] array2 = {1,2,3,4,5};
		System.out.println(array2[0]);
		
		
	}

}

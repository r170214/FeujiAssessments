//5. Write a program to throw ArrayIndexOutOfBoundsException

package com.arrays.nov8;

public class ArrayIndexOutOfBoundsExceptionProgram5 {

	public static void main(String[] args) 
	{
		int[] array = new int[5];
		System.out.println(array[6]);//it will throw arrayIndexOutOfBoundsException

	}

}

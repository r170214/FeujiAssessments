//Write a program to declare an array without assigning the size
package com.arrays.nov8;

public class ArrayDeclarationWithoutSize6 {

	public static void main(String[] args) 
	{
		int[] arr =new int[] {};
		
		int[] array= {};
		System.out.println("length of array is: "+array.length);
		/*
		 * above approach will work for array declaration without size
		 */
	}

}
